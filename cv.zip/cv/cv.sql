-- phpMyAdmin SQL Dump
-- version 4.8.3
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Mar 14, 2019 at 04:18 AM
-- Server version: 10.1.36-MariaDB
-- PHP Version: 7.2.11

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `cv`
--

-- --------------------------------------------------------

--
-- Table structure for table `aboutme`
--

CREATE TABLE `aboutme` (
  `id_aboutme` int(11) NOT NULL,
  `name_aboutme` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `detail_aboutme` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `phone_aboutme` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `address_aboutme` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `email_aboutme` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `avatar_aboutme` varchar(255) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `aboutme`
--

INSERT INTO `aboutme` (`id_aboutme`, `name_aboutme`, `detail_aboutme`, `phone_aboutme`, `address_aboutme`, `email_aboutme`, `avatar_aboutme`) VALUES
(1, 'LÊ VĂN TÙNG', 'Tôi tên là Lê Văn Tùng, sinh ngày 09 tháng 6 năm 1996 tại Đà Nẵng. Tôi có nhiều sở thích như tự nghiên cứu về lập trình web, thích đọc blog như Tôi đi code dạo, lập trình cuộc sống, Viblo.asia, nghe nhạc, chơi game, trò chuyện với bạn bè...', '0905794743', 'Tổ 71 Trần Cao Vân, Xuân Hà, Thanh Khê, Đà Nẵng', 'lvtungdn43@gmail.com', 'anh.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `edu`
--

CREATE TABLE `edu` (
  `id_edu` int(10) NOT NULL,
  `name_edu` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `address_edu` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `time_edu` year(4) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `edu`
--

INSERT INTO `edu` (`id_edu`, `name_edu`, `address_edu`, `time_edu`) VALUES
(1, 'CĐCN', '02 Cao Thắng', 2015);

-- --------------------------------------------------------

--
-- Table structure for table `exp`
--

CREATE TABLE `exp` (
  `id_exp` int(10) NOT NULL,
  `name_exp` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `detail_exp` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `time_exp` year(4) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `exp`
--

INSERT INTO `exp` (`id_exp`, `name_exp`, `detail_exp`, `time_exp`) VALUES
(1, 'CV', 'demo', 2018);

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `id_user` int(10) NOT NULL,
  `username` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `password` varchar(50) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`id_user`, `username`, `password`) VALUES
(1, 'tung', '123');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `aboutme`
--
ALTER TABLE `aboutme`
  ADD PRIMARY KEY (`id_aboutme`);

--
-- Indexes for table `edu`
--
ALTER TABLE `edu`
  ADD PRIMARY KEY (`id_edu`);

--
-- Indexes for table `exp`
--
ALTER TABLE `exp`
  ADD PRIMARY KEY (`id_exp`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`id_user`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `aboutme`
--
ALTER TABLE `aboutme`
  MODIFY `id_aboutme` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `edu`
--
ALTER TABLE `edu`
  MODIFY `id_edu` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `exp`
--
ALTER TABLE `exp`
  MODIFY `id_exp` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `id_user` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
